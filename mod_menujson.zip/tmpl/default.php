<?php defined('_JEXEC') or die; ?>
<script type="text/javascript" src="<?php echo $Menumob; ?>"></script>
<nav class="menulateral hidden-md hidden-lg" id="menu-mobile">  	   
</nav>





