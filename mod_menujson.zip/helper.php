<?php
class ModMenu
{    public static function getMenu($params)
    {
        return  "/modules/mod_menujson/js/menuviajson.min.js" ;
    }
}
?>

